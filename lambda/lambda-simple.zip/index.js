exports.handler = async (event) => {
  console.log('Lambda function called with event:', JSON.stringify(event, null, 2));
  
  try {
    const action = event?.action;
    
    if (action === 'test') {
      return {
        statusCode: 200,
        body: JSON.stringify({
          message: 'Hello from Lambda!',
          action: action,
          timestamp: new Date().toISOString()
        })
      };
    }
    
    if (action === 'deploy') {
      return {
        statusCode: 200,
        body: JSON.stringify({
          message: 'Deployment would start here',
          agentId: event?.agentId,
          config: event?.config,
          timestamp: new Date().toISOString()
        })
      };
    }
    
    return {
      statusCode: 400,
      body: JSON.stringify({
        error: 'Unknown action',
        receivedAction: action
      })
    };
    
  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message
      })
    };
  }
};
